use my_cat;
create table Class_Board(
	C_No int primary key auto_increment,
    C_Name char(20),
    C_Class char(20),
	C_Gender char(10),
    C_Unit char(10),
    C_Cost char(15),
    C_Type1 char(25),
    C_Type2 boolean default false,
    C_Identity boolean default false,
    C_Hell boolean default false
);

drop table Class_Board;
insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity ) values ('전투태세', '워로드', '남자', '근접딜러', '가격이 비교적 낮음', '지속딜러', 1, 0);
insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity) values ('고독한 기사', '워로드', '남자', '근접딜러', '가격이 비교적 낮음', '한방이 강한 딜러', 1, 0);

insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity) values ('광전사의 비기', '버서커', '남자', '근접딜러', '가격이 비교적 낮음', '한방이 강한 딜러', 1, 1);
insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity) values ('광기', '버서커', '남자', '근접딜러', '가격이 비교적 낮음', '지속딜러', 1, 0);

insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity) values ('중력수련', '디스트로이어', '남자', '근접딜러', '가격이 비교적 낮음', '지속딜러', 0, 1);
insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity) values ('분노의 망치', '디스트로이어', '남자', '근접딜러', '가격이 비교적 낮음', '한방이 강한 딜러', 1, 1);

insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type2, C_Identity, C_Hell) values ('축복의 오라', '홀리나이트', '남자', '서포터', '가격이 비교적 낮음', 0, 1, 1);
insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity) values ('심판자', '홀리나이트', '남자', '근접딜러', '가격이 비교적 낮음', '지속딜러', 0, 1);

insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity, C_Hell) values ('포식자', '슬레이어', '여자', '근접딜러', '가격이 비교적 높음', '지속딜러', 0, 1, 1);
insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity) values ('처단자', '슬레이어', '여자', '근접딜러', '가격이 비교적 높음', '한방이 강한 딜러', 1, 1);

insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity) values ('극의:체술', '인파이터', '여자', '근접딜러', '가격이 비교적 낮음', '지속딜러', 0, 1);
insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity) values ('충격 단련', '인파이터', '여자', '근접딜러', '가격이 비교적 높음', '한방이 강한 딜러', 1, 1);

insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity) values ('초심', '배틀마스터', '여자', '근접딜러', '가격이 비교적 낮음', '지속딜러', 1, 0);
insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity) values ('오의강화', '배틀마스터', '여자', '근접딜러', '가격이 비교적 높음', '한방이 강한 딜러', 1, 1);

insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity) values ('세맥타통', '기공사', '여자', '근접딜러', '가격이 비교적 낮음', '한방이 강한 딜러', 1, 1);
insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity) values ('역천지체', '기공사', '여자', '근접딜러', '가격이 비교적 높음', '한방이 강한 딜러', 1, 1);

insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity) values ('절제', '창술사', '여자', '근접딜러', '가격이 비교적 낮음', '지속딜러', 1, 0);
insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity, C_Hell) values ('절정', '창술사', '여자', '근접딜러', '가격이 비교적 높음', '한방이 강한 딜러', 1, 1, 1);

insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity) values ('오의 난무', '스트라이커', '남자', '근접딜러', '가격이 비교적 높음', '한방이 강한 딜러', 1, 1);
insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity) values ('일격 필살', '스트라이커', '남자', '근접딜러', '가격이 비교적 높음', '한방이 강한 딜러', 1, 1);

insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity) values ('강화 무기', '데빌헌터', '남자', '근접딜러', '가격이 비교적 높음', '한방이 강한 딜러', 1, 0);
insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity) values ('핸드거너', '데빌헌터', '남자', '근접딜러', '가격이 비교적 낮음', '지속딜러', 0, 0);

insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity, C_Hell) values ('두 번째 동료', '호크아이', '남자', '원거리딜러', '가격이 비교적 높음', '지속딜러', 0, 0, 1);
insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity, C_Hell) values ('죽음의 습격', '호크아이', '남자', '중거리딜러', '가격이 비교적 낮음', '지속딜러', 1, 1, 1);

insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity) values ('화력 강화', '블래스터', '남자', '중거리딜러', '가격이 비교적 낮음', '지속딜러', 0, 0);
insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity) values ('포격 강화', '블래스터', '남자', '근접딜러', '가격이 비교적 높음', '한방이 강한 딜러', 0, 1);

insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity) values ('진화의 유산', '스카우터', '남자', '근접딜러', '가격이 비교적 낮음', '지속딜러', 1, 1);
insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity, C_Hell) values ('아르데타인의 기술', '스카우터', '남자', '근접딜러', '가격이 비교적 낮음', '지속딜러', 1, 0, 1);

insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity, C_Hell) values ('피스메이커', '건슬링어', '여자', '중거리딜러', '가격이 비교적 높음', '지속딜러', 1, 1, 1);
insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity) values ('사냥의 시간', '건슬링어', '여자', '원거리딜러', '가격이 비교적 높음', '지속딜러', 1, 0);

insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity) values ('황제의 칙령', '아르카나', '여자', '근거리딜러', '가격이 비교적 낮음', '지속딜러', 0, 0);
insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity) values ('황후의 은총', '아르카나', '여자', '근거리딜러', '가격이 비교적 높음', '지속딜러', 1, 1);

insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity, C_Hell) values ('넘치는 교감', '서머너', '여자', '원거리딜러', '가격이 비교적 낮음', '지속딜러', 1, 1, 1);
insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity) values ('상급 소환사', '서머너', '여자', '원거리딜러', '가격이 비교적 높음', '한방이 강한 딜러', 1, 1);

insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type2, C_Identity) values ('절실한 구원', '바드', '여자', '서포터', '가격이 비교적 낮음', 1, 1);
insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity) values ('진실된 용맹', '바드', '여자', '중거리딜러', '가격이 비교적 낮음', '지속딜러', 1, 0);

insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity) values ('환류', '소서리스', '여자', '원거리딜러', '가격이 비교적 낮음', '지속딜러', 0, 0);
insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity) values ('점화', '소서리스', '여자', '원거리딜러', '가격이 비교적 낮음', '한방이 강한 딜러', 1, 1);

insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity) values ('잔재된 기운', '블레이드', '여자', '근접딜러', '가격이 비교적 낮음', '지속딜러', 1, 1);
insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity) values ('버스트', '블레이드', '여자', '근접딜러', '가격이 비교적 높음', '한방이 강한 딜러', 0, 1);

insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity) values ('멈출 수 없는 충동', '데모닉', '여자', '근접딜러', '가격이 비교적 낮음', '지속딜러', 0, 1);
insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity) values ('완벽한 억제', '데모닉', '여자', '근접딜러', '가격이 비교적 낮음', '지속딜러', 1, 1);

insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity) values ('달의 소리', '리퍼', '여자', '근접딜러', '가격이 비교적 높음', '한방이 강한 딜러', 1, 1);
insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity) values ('갈증', '리퍼', '여자', '근접딜러', '가격이 비교적 낮음', '지속딜러', 0, 1);

insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type2, C_Identity) values ('만개', '도화가', '여자', '서포터', '가격이 비교적 낮음', 1, 1);
insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity) values ('회귀', '도화가', '여자', '근접딜러', '가격이 비교적 낮음', '지속딜러', 1, 0);

insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity) values ('이슬비', '기상술사', '여자', '원거리딜러', '가격이 비교적 높음', '지속딜러', 1, 1);
insert into Class_Board (C_Name, C_Class, C_Gender, C_Unit, C_Cost, C_Type1, C_Type2, C_Identity) values ('이슬비', '기상술사', '여자', '근접딜러', '가격이 비교적 낮음', '지속딜러', 1, 1);

SELECT C_Name, C_Class FROM Class_Board WHERE C_Gender LIKE '%%' AND C_Unit LIKE '%%' AND C_Cost LIKE '%%' AND C_Type1 LIKE '%%' AND C_Type2 LIKE '%%' AND C_Identity LIKE '%%' AND C_Hell LIKE '%%';
SELECT C_Name, C_Class
FROM Class_Board
WHERE C_Gender LIKE '%%'
  AND C_Unit LIKE '%%'
  AND C_Cost LIKE '%%'
  AND C_Type1 LIKE '%%'
  AND C_Type2 LIKE '%%'
  AND C_Identity LIKE '%%'
  AND C_Hell LIKE '%%';
Select * from Class_Board;