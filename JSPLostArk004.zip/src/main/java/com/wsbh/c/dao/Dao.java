package com.wsbh.c.dao;

import java.sql.ResultSet;
import java.util.ArrayList;

import com.wsbh.c.dto.Dto;

public class Dao extends Dao_F {
	
	ResultSet result;
	
	
	public ArrayList<Dto> list(Dto dto_Object) {
		ArrayList<Dto> posts = new ArrayList<>();
		try {
			super.DB_Con();
			String sql = String.format("SELECT C_Name, C_Class FROM Class_Board WHERE C_Gender LIKE '%%%s%%' AND C_Unit LIKE '%%%s%%' AND C_Cost LIKE '%%%s%%' AND C_Type1 LIKE '%%%s%%' AND C_Type2 LIKE '%%%s%%' AND C_Identity LIKE '%%%s%%' AND C_Hell LIKE '%%%s%%'", 
					dto_Object.c_Gender, 
					dto_Object.c_Unit, 
					dto_Object.c_Cost, 
					dto_Object.c_Type1,
					dto_Object.c_Type2,
					dto_Object.c_Identity,
					dto_Object.c_Hell
					);
			result = st.executeQuery(sql);
			System.out.println("sql : "+ sql);
			while(result.next()) {
				posts.add(new Dto(result.getString("C_Name"), result.getString("C_Class")));
			}
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println("문제가 있다옹");
		}
		return posts;
	}
}
