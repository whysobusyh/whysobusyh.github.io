package com.wsbh.c.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import com.wsbh.c.db.Db;

public class Dao_F {
	public Connection con = null;
	public Statement st = null;
	public ResultSet result = null;
	public void DB_Con() {
		try {
			Class.forName(Db.DB_JDBC_DRIVER_PACKAGE_PATH);
			con = DriverManager.getConnection(Db.DB_URL,Db.DB_ID,Db.DB_PW);
			st = con.createStatement();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void DB_Close() {
		try {
			st.close();
			con.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
