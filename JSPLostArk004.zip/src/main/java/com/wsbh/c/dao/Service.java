package com.wsbh.c.dao;

public class Service {
	
	Dao dao;
	
	public Service(){
		dao = new Dao();
	}
	
	public void gender_box(String gender) {
		
	}
}
