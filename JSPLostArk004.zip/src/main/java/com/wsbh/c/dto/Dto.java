package com.wsbh.c.dto;

public class Dto {
	
	public String c_No       ;
	public String c_Name     ;
	public String c_Class    ;
	public String c_Gender   ;
	public String c_Unit     ;
	public String c_Cost     ;
	public String c_Type1    ;
	public String c_Type2    ;
	public String c_Identity ;
	public String c_Hell     ;
	
	public Dto(String c_Name, String c_Class, String c_Gender, String c_Unit, String c_Cost, String c_Type1,
			String c_Type2, String c_Identity, String c_Hell) {
		super();
		this.c_Name = c_Name;
		this.c_Class = c_Class;
		this.c_Gender = c_Gender;
		this.c_Unit = c_Unit;
		this.c_Cost = c_Cost;
		this.c_Type1 = c_Type1;
		this.c_Type2 = c_Type2;
		this.c_Identity = c_Identity;
		this.c_Hell = c_Hell;
	}

	public Dto(String c_Gender, String c_Unit, String c_Cost, String c_Type1, String c_Type2, String c_Identity,
			String c_Hell) {
		super();
		this.c_Gender = c_Gender;
		this.c_Unit = c_Unit;
		this.c_Cost = c_Cost;
		this.c_Type1 = c_Type1;
		this.c_Type2 = c_Type2;
		this.c_Identity = c_Identity;
		this.c_Hell = c_Hell;
	}

	public Dto(String c_Name, String c_Class) {
		super();
		this.c_Name = c_Name;
		this.c_Class = c_Class;
	}                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   
	
	
}
