package com.wsbh.c.Controller;

import java.io.IOException;

import com.wsbh.c.dao.Dao;
import com.wsbh.c.dao.Service;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class BoardController
 */
@WebServlet("/board/*")
public class BoardController extends HttpServlet {
	String next_Page;
	Dao dao ;
	Service service;
	
	@Override
	public void init() throws ServletException{
		service = new Service();
		
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getPathInfo();
		// 사용자가 액션을 했을때 경로
		System.out.println("action : " + action);
		// 콘솔에 경로 추가
		
		if(action!=null) {
		//액션이 null이 아니라면
			switch(action) {
			// switch문을 써서 케이스 별로 설명
			case "/gender_box" :
				next_Page = "/index.jsp";
				System.out.println("성별");
				String gender_Sel= request.getParameter("gender");
				request.getSession().setAttribute("gender_Sel", gender_Sel);
				break;
			case "/unit_box" :
				next_Page = "/index.jsp";
				System.out.println("유닛");
				String unit_Sel= request.getParameter("unit");
				request.getSession().setAttribute("unit_Sel", unit_Sel);
				break;
			case "/cost_box" :
				next_Page = "/index.jsp";
				System.out.println("비용");
				String cost_Sel= request.getParameter("cost");
				request.getSession().setAttribute("cost_Sel", cost_Sel);
				break;
			case "/type1_box" :
				next_Page = "/index.jsp";
				System.out.println("타입1");
				String type1_Sel= request.getParameter("type1");
				request.getSession().setAttribute("type1_Sel", type1_Sel);
				break;
			case "/type2_box" :
				next_Page = "/index.jsp";
				System.out.println("타입2");
				String type2_Sel= request.getParameter("type2");
				request.getSession().setAttribute("type2_Sel", type2_Sel);
				break;
			case "/identity_box" :
				next_Page = "/index.jsp";
				System.out.println("아덴");
				String identity_Sel= request.getParameter("identity");
				request.getSession().setAttribute("identity_Sel", identity_Sel);
				break;
			case "/hell_box" :
				next_Page = "/index.jsp";
				System.out.println("헬");
				String hell_Sel= request.getParameter("hell");
				request.getSession().setAttribute("hell_Sel", hell_Sel);
				break;
			}
			RequestDispatcher d = request.getRequestDispatcher(next_Page);
			d.forward(request, response);
			
		}
		
		
	}

}
